package com.DataOperatingservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;


@SpringBootApplication
@EnableFeignClients

//@EnableDiscoveryClient
public class DataOperatingServiceApplication {

	private static final Logger logger = LoggerFactory.getLogger(DataOperatingServiceApplication.class);

	public static void main(String[] args) {
		logger.info("Starting DataOperatingServiceApplication...");
		SpringApplication.run(DataOperatingServiceApplication.class, args);
		logger.info("DataOperatingServiceApplication started successfully.");
	}
}