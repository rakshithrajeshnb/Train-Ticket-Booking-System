package com.DataOperatingservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.DataOperatingservice.dto.TrainDetails;
import com.DataOperatingservice.dto.Traindto;
import com.DataOperatingservice.proxy.BookingServiceProxy;
import com.DataOperatingservice.proxy.SearchingControllerProxy;
import com.railway.searching.service.exception.TrainNotFoundException;

@RestController
@RequestMapping("/admin")
public class OperationController {

	// Logger for logging important events and debugging information
	private static final Logger logger = LoggerFactory.getLogger(OperationController.class);

	@Autowired
	private SearchingControllerProxy proxy;

	@Autowired
	private BookingServiceProxy proxy1;

	// Endpoint to add train details
	@PostMapping("/add")
	public String addTrain1(@RequestBody TrainDetails tdetails) {
		logger.info("Adding train details for train: {}", tdetails.getTrainNo());

		Traindto obj = new Traindto(tdetails.getTrainNo(), tdetails.getTrainName(), tdetails.getAvsl(),
				tdetails.getAv2a(), tdetails.getAv3a(), tdetails.getTrainSchedule());
		proxy1.adddetails(obj);

		String msg = proxy.addTrainDetails(tdetails);
		logger.info("Train details added successfully for train: {}", tdetails.getTrainNo());
		return msg;
	}

	// Endpoint to remove train details
	@DeleteMapping("/removetrain/{id}")
	public String deleteTrain(@PathVariable int id) {
		logger.info("Removing train with ID: {}", id);

		proxy1.removetrain(String.valueOf(id));
		String msg = proxy.deleteTrain(id);
		logger.info("Train with ID {} removed successfully.", id);
		return msg;
	}

	// Endpoint to update train details
	@PutMapping("/updatetrain")
	public String updateTrain(@RequestBody TrainDetails trainDetails) throws TrainNotFoundException {
		logger.info("Updating train details for train: {}", trainDetails.getTrainNo());

		String msg = proxy.updateTrain(trainDetails);
		logger.info("Train details updated successfully for train: {}", trainDetails.getTrainNo());
		return msg;
	}
}