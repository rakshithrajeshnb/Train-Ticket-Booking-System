package com.DataOperatingservice.dto;

import java.sql.Date;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TrainRoutes {
    private int srNo;
    private TrainDetails traindetails;
    private String divSource;
    private String divDest;
    private String source;
    private String destination;
    private String startArrivalTime;
    private String endArrivalTime;
    private Date date;
    private int slFare;
    private int twoACFare;
    private int threeACFare;
}