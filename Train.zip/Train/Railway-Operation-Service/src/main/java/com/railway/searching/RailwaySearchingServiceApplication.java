package com.railway.searching;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@SpringBootApplication
@ComponentScan(basePackages = {"com.railway.searching", "com.railway.searching.controller", "com.railway.otherpackage"})
@EnableDiscoveryClient
@EnableAspectJAutoProxy
//@CrossOrigin(origins="http://localhost:4200")
public class RailwaySearchingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RailwaySearchingServiceApplication.class, args);
	}

	
}
