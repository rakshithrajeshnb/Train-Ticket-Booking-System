package com.railway.searching.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.railway.searching.entity.Train;
import com.railway.searching.entity.TrainDetails;
import com.railway.searching.exception.TrainNotFoundException;
import com.railway.searching.service.SearchingService;

@RestController
public class SearchingController {

    // Logger for logging important events and debugging information
    private static final Logger logger = LoggerFactory.getLogger(SearchingController.class);

    @Autowired
    private SearchingService service;

    // Endpoint to search for trains
    @PostMapping("/gettrains") // http://localhost:9191/gettrains
    public Object searchTrain(@RequestBody Map<String, Object> details) {
        String source = details.get("source").toString();
        String dest = details.get("destination").toString();
        String date = details.get("date").toString();
        LocalDate date1 = LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd"));

        logger.info("Searching for trains from {} to {} on {}", source, dest, date1);

        try {
            List<Train> result = service.searchTrain(source, dest, date1);
            logger.info("Trains found: {}", result);
            return result;
        } catch (TrainNotFoundException e) {
            String errorMessage = e.getMessage();
            logger.error("Error finding trains: {}", errorMessage);
            return errorMessage;
        }
    }

    // Endpoint to add train details
    @PostMapping("/add") // http://localhost:9191/add
    public String addTrainDetails(@RequestBody TrainDetails trainDetails) {
        logger.info("Adding train details for train: {}", trainDetails.getTrainNo());
        String msg = service.addTrainDetails(trainDetails);
        logger.info("Train details added successfully for train: {}", trainDetails.getTrainNo());
        return msg;
    }

    // Endpoint to remove train details
    @DeleteMapping("/removetrain") // http://localhost:9191/removetrain
    public String deleteTrain(@RequestBody int id) {
        logger.info("Removing train with ID: {}", id);
        try {
            String msg = service.deleteTrain(id);
            logger.info("Train with ID {} removed successfully.", id);
            return msg;
        } catch (Exception e) {
            logger.error("Error removing train with ID: {}", id, e);
            return e.getMessage();
        }
    }

    // Endpoint to update train details
    @PutMapping("/updatetrain")
    public String updateTrain(@RequestBody TrainDetails trainDetails) throws TrainNotFoundException {
        logger.info("Updating train details for train: {}", trainDetails.getTrainNo());
        String msg = service.updateTrain(trainDetails);
        logger.info("Train details updated successfully for train: {}", trainDetails.getTrainNo());
        return msg;
    }

    // Endpoint to decrease seat count
    @PutMapping("/lesscount") 	//http://localhost:9191/lesscount
    public void lesscount(@RequestBody List<String> lst) {
        logger.info("Decreasing seat count for train: {}", lst);
        service.lesscount(lst);
        logger.info("Seat count decreased successfully for train: {}", lst);
    }
}