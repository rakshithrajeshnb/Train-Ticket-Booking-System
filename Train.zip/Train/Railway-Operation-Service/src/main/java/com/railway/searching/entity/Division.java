package com.railway.searching.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Division_Record")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Division {

    @Id
    @NotNull(message = "Station name must not be blank")
    private String stationName;

    @NotNull(message = "Station division must not be blank")
    private String stationDivision;
    
    public String getstationDivision() {
		return stationDivision;
	}
}