package com.railway.searching.entity;

import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Train {
    private String number;
    private String name;
    private String source;
    private String destination;
    private String startArrivalTime;
    private String endArrivalTime;
    private Date date;
    private int avsl;
    private int av2a;
    private int av3a;
    private int slFare;
    private int twoACFare;
    private int threeACFare;
}