package com.railway.searching.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "train_details")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TrainDetails {

    @Id
//    @NotBlank(message = "Train number must not be blank")
    private String trainNo;

//    @NotNull(message = "Train name must not be blank")
    private String trainName;

//    @Min(value = 0, message = "Available 2A seats must be non-negative")
    private int av2a;

//    @Min(value = 0, message = "Available 3A seats must be non-negative")
    private int av3a;

//    @Min(value = 0, message = "Available SL seats must be non-negative")
    private int avsl;

    @OneToMany(mappedBy = "traindetails")
    private List<TrainRoutes> trainRoutes;

    @OneToMany(mappedBy = "trainDetails", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Dates> trainSchedule;
    
    
}