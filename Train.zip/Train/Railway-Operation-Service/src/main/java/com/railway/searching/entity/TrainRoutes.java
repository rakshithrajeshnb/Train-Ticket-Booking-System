package com.railway.searching.entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity 
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TrainRoutes {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int srNo;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "trainNo")
//    @NotNull(message = "Train details must not be null")
    private TrainDetails traindetails;

//    @NotNull(message = "Division source must not be null")
//    @Size(min = 2, max = 50, message = "Division source must be between 2 and 50 characters")
    private String divSource;

//    @NotNull(message = "Division destination must not be null")
//    @Size(min = 2, max = 50, message = "Division destination must be between 2 and 50 characters")
    private String divDest;

//    @NotNull(message = "Source must not be null")
//    @Size(min = 2, max = 50, message = "Source must be between 2 and 50 characters")
    private String source;

//    @NotNull(message = "Destination must not be null")
    @Size(min = 2, max = 50, message = "Destination must be between 2 and 50 characters")
    private String destination;

//    @NotNull(message = "Start arrival time must not be null")
    private String startArrivalTime;

//    @NotNull(message = "End arrival time must not be null")
    private String endArrivalTime;

//    @NotNull(message = "Date must not be null")
//    @PastOrPresent(message = "Date must be in the past or present")
    private Date date;

//    @Min(value = 0, message = "Sleeper fare must be at least 0")
    private int slFare;

//    @Min(value = 0, message = "2AC fare must be at least 0")
    private int twoACFare;

//    @Min(value = 0, message = "3AC fare must be at least 0")
    private int threeACFare;
    
    
}