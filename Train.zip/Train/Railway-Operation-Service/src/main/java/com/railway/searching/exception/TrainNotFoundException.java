package com.railway.searching.exception;

public class TrainNotFoundException extends Exception{

	public TrainNotFoundException(String msg)
	{
		super(msg);
	}
}








