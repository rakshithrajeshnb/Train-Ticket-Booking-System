package com.railway.searching.logaspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspectAfter {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Before("within(com.railway.searching.service.service.*)")
    public void logBeforeAllServiceClassMethods() {
        LOGGER.debug("For All Services");
    }

    @After("execution(* com.railway.searching.service.service.SearchingService.*(..))")
    public void logAfterAllMethods(JoinPoint joinPoint) {
        LOGGER.debug("****LoggingAspect.logAfterAllMethods() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* com.railway.searching.service.service.SearchingService.addTrainDetails(..))")
    public void logAfterAddTrainDetails(JoinPoint joinPoint) {
        LOGGER.debug("****LoggingAspect.logAfterAddTrainDetails() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* com.railway.searching.service.service.SearchingService.searchTrain(..))")
    public void logAfterSearchTrain(JoinPoint joinPoint) {
        LOGGER.debug("****LoggingAspect.logAfterSearchTrain() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* com.railway.searching.service.service.SearchingService.deleteTrain(..))")
    public void logAfterDeleteTrain(JoinPoint joinPoint) {
        LOGGER.debug("****LoggingAspect.logAfterDeleteTrain() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* com.railway.searching.service.service.SearchingService.updateTrain(..))")
    public void logAfterUpdateTrain(JoinPoint joinPoint) {
        LOGGER.debug("****LoggingAspect.logAfterUpdateTrain() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* com.railway.searching.service.service.SearchingService.lesscount(..))")
    public void logAfterLesscount(JoinPoint joinPoint) {
        LOGGER.debug("****LoggingAspect.logAfterLesscount() : " + joinPoint.getSignature().getName());
    }
}