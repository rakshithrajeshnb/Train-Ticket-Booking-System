package com.railway.searching.logaspects;

import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspectAfterReturning {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @AfterReturning("execution(* com.railway.searching.service.SearchingService.*(..))")
    public void logAfterReturningAllMethods() throws Throwable {
        LOGGER.debug("****LoggingAspect.logAfterReturningAllMethods() ");
    }

    @AfterReturning(pointcut = "execution(* com.railway.searching.service.SearchingService.addTrainDetails(..))", returning = "retVal")
    public void logAfterReturningAddTrainDetails(Object retVal) throws Throwable {
        LOGGER.debug("****LoggingAspect.logAfterReturningAddTrainDetails() ");
    }

    @AfterReturning(pointcut = "execution(* com.railway.searching.service.SearchingService.searchTrain(..))", returning = "retVal")
    public void logAfterReturningSearchTrain(Object retVal) throws Throwable {
        LOGGER.debug("****LoggingAspect.logAfterReturningSearchTrain() ");
    }

    @AfterReturning(pointcut = "execution(* com.railway.searching.service.SearchingService.deleteTrain(..))", returning = "retVal")
    public void logAfterReturningDeleteTrain(Object retVal) throws Throwable {
        LOGGER.debug("****LoggingAspect.logAfterReturningDeleteTrain() ");
    }

    @AfterReturning(pointcut = "execution(* com.railway.searching.service.SearchingService.updateTrain(..))", returning = "retVal")
    public void logAfterReturningUpdateTrain(Object retVal) throws Throwable {
        LOGGER.debug("****LoggingAspect.logAfterReturningUpdateTrain() ");
    }

    @AfterReturning(pointcut = "execution(* com.railway.searching.service.SearchingService.lesscount(..))", returning = "retVal")
    public void logAfterReturningLesscount(Object retVal) throws Throwable {
        LOGGER.debug("****LoggingAspect.logAfterReturningLesscount() ");
    }
}