package com.railway.searching.logaspects;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspectAround {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Around("execution(* com.railway.searching.service.service.SearchingService.*(..))")
    public void logAroundAllMethods(ProceedingJoinPoint joinPoint) throws Throwable {
        LOGGER.debug("****LoggingAspect.logAroundAllMethods() : " + joinPoint.getSignature().getName() + ": Before Method Execution");
        joinPoint.proceed();
        LOGGER.debug("****LoggingAspect.logAroundAllMethods() : " + joinPoint.getSignature().getName() + ": After Method Execution");
    }

    @Around("execution(* com.railway.searching.service.service.SearchingService.addTrainDetails(..))")
    public void logAroundAddTrainDetails(ProceedingJoinPoint joinPoint) throws Throwable {
        LOGGER.debug("****LoggingAspect.logAroundAddTrainDetails() : " + joinPoint.getSignature().getName() + ": Before Method Execution");
        joinPoint.proceed();
        LOGGER.debug("****LoggingAspect.logAroundAddTrainDetails() : " + joinPoint.getSignature().getName() + ": After Method Execution");
    }

    @Around("execution(* com.railway.searching.service.service.SearchingService.searchTrain(..))")
    public void logAroundSearchTrain(ProceedingJoinPoint joinPoint) throws Throwable {
        LOGGER.debug("****LoggingAspect.logAroundSearchTrain() : " + joinPoint.getSignature().getName() + ": Before Method Execution");
        joinPoint.proceed();
        LOGGER.debug("****LoggingAspect.logAroundSearchTrain() : " + joinPoint.getSignature().getName() + ": After Method Execution");
    }

    @Around("execution(* com.railway.searching.service.service.SearchingService.deleteTrain(..))")
    public void logAroundDeleteTrain(ProceedingJoinPoint joinPoint) throws Throwable {
        LOGGER.debug("****LoggingAspect.logAroundDeleteTrain() : " + joinPoint.getSignature().getName() + ": Before Method Execution");
        joinPoint.proceed();
        LOGGER.debug("****LoggingAspect.logAroundDeleteTrain() : " + joinPoint.getSignature().getName() + ": After Method Execution");
    }

    @Around("execution(* com.railway.searching.service.service.SearchingService.updateTrain(..))")
    public void logAroundUpdateTrain(ProceedingJoinPoint joinPoint) throws Throwable {
        LOGGER.debug("****LoggingAspect.logAroundUpdateTrain() : " + joinPoint.getSignature().getName() + ": Before Method Execution");
        joinPoint.proceed();
        LOGGER.debug("****LoggingAspect.logAroundUpdateTrain() : " + joinPoint.getSignature().getName() + ": After Method Execution");
    }

    @Around("execution(* com.railway.searching.service.service.SearchingService.lesscount(..))")
    public void logAroundLesscount(ProceedingJoinPoint joinPoint) throws Throwable {
        LOGGER.debug("****LoggingAspect.logAroundLesscount() : " + joinPoint.getSignature().getName() + ": Before Method Execution");
        joinPoint.proceed();
        LOGGER.debug("****LoggingAspect.logAroundLesscount() : " + joinPoint.getSignature().getName() + ": After Method Execution");
    }
}