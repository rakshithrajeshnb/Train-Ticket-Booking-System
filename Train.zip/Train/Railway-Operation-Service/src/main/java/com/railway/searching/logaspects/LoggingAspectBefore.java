package com.railway.searching.logaspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspectBefore {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Before("execution(* com.railway.searching.service.service.SearchingService.*(..))")
    public void logBeforeAllMethods(JoinPoint joinPoint) {
        LOGGER.info("****LoggingAspect.logBeforeAllMethods() : " + joinPoint.getSignature().getName());
    }

    @Before("execution(* com.railway.searching.service.service.SearchingService.addTrainDetails(..))")
    public void logBeforeAddTrainDetails(JoinPoint joinPoint) {
        LOGGER.info("****LoggingAspect.logBeforeAddTrainDetails() : " + joinPoint.getSignature().getName());
    }

    @Before("execution(* com.railway.searching.service.service.SearchingService.searchTrain(..))")
    public void logBeforeSearchTrain(JoinPoint joinPoint) {
        LOGGER.info("****LoggingAspect.logBeforeSearchTrain() : " + joinPoint.getSignature().getName());
    }

    @Before("execution(* com.railway.searching.service.service.SearchingService.deleteTrain(..))")
    public void logBeforeDeleteTrain(JoinPoint joinPoint) {
        LOGGER.info("****LoggingAspect.logBeforeDeleteTrain() : " + joinPoint.getSignature().getName());
    }

    @Before("execution(* com.railway.searching.service.service.SearchingService.updateTrain(..))")
    public void logBeforeUpdateTrain(JoinPoint joinPoint) {
        LOGGER.info("****LoggingAspect.logBeforeUpdateTrain() : " + joinPoint.getSignature().getName());
    }

    @Before("execution(* com.railway.searching.service.service.SearchingService.lesscount(..))")
    public void logBeforeLesscount(JoinPoint joinPoint) {
        LOGGER.info("****LoggingAspect.logBeforeLesscount() : " + joinPoint.getSignature().getName());
    }
}