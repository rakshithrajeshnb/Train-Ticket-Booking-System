package com.railway.searching.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.railway.searching.entity.Dates;


@Repository
public interface DatesRepository extends JpaRepository<Dates,Long>{

}
