package com.railway.searching.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.railway.searching.entity.TrainRoutes;


@Repository
public interface TrainRoutesRepository extends JpaRepository<TrainRoutes,Integer>{

}
