package com.RailwayOperationService;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

//import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.railway.searching.RailwaySearchingServiceApplication;
import com.railway.searching.controller.SearchingController;
import com.railway.searching.entity.Train;
import com.railway.searching.exception.TrainNotFoundException;

@SpringBootTest(classes = RailwaySearchingServiceApplication.class)
class RailwayOperationServiceApplicationTests {

		@Mock
	    private SearchingController controller;

		@BeforeEach
		void setUp() {
			MockitoAnnotations.openMocks(this);
		}

	    @Test
	    void testSearchTrain() throws TrainNotFoundException, ParseException {

	        Map<String, Object> details = Map.of(
	            "source", "Majestic",
	            "destination", "Kacheguda",
	            "date", "2025-03-15"
	        );
	        List<Train> expectedTrains = new ArrayList<>();
		    Date date2 = (Date) new SimpleDateFormat("yyyy-MM-dd").parse("2025-04-01");
		    
		    Train t1 = new Train("12116", "Siddheshwar Express", "Solapur", "Thane", "10:30 PM", "5:40 AM", date2, 0, 600, 600, 295, 1050, 750);
		    Train t2 = new Train("11302", "Udyan Express", "Solapur", "CSMT", "10:55 AM", "8:15 PM", date2, 600, 600, 600, 275, 1050, 745);
		    expectedTrains.add(t1);
		    expectedTrains.add(t2);

		    when(controller.searchTrain(details)).thenReturn(expectedTrains);

	        List<Train> actualTrains = (List<Train>) controller.searchTrain(details);

	        assertEquals(expectedTrains, actualTrains);
	    }

	}

