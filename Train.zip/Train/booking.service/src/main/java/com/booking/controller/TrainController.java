package com.booking.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.booking.dto.Form;
import com.booking.dto.Traindto;
import com.booking.entity.TrainSeats;
import com.booking.service.TrainService;

@RestController
@RequestMapping("/book")
public class TrainController {
    
    // Logger for logging important events and debugging information
    static final Logger logger = LoggerFactory.getLogger(TrainController.class);
    
    // Autowiring the TrainService to use its methods
    @Autowired
    private TrainService service;
    
    // Endpoint to add train details
    @PostMapping("/addseats")    //http://localhost:9195/book/addseats
    public void adddetails(@RequestBody Traindto obj) {
        logger.info("Received request to add train details: {}", obj); // Log the incoming request
        service.adddetails(obj); // Call the service method to add train details
        logger.info("Train details added successfully."); // Log the successful addition
    }
    
    // Endpoint to remove train details
    @DeleteMapping("/removeseats")    //http://localhost:9195/book/removeseats
    public void removetrain(@RequestBody String id) {
        logger.info("Received request to remove train with ID: {}", id); // Log the incoming request
        service.removetrain(id); // Call the service method to remove train details
        logger.info("Train with ID {} removed successfully.", id); // Log the successful removal
    }
    
    // Endpoint to book tickets
    @PostMapping("/ticket")        //http://localhost:9195/book/ticket
    public List<Object> bookTickets(@RequestBody List<Form> lst) {
        logger.info("Received request to book tickets: {}", lst); // Log the incoming request
        List<Object> response = service.bookTickets(lst); // Call the service method to book tickets
        logger.info("Tickets booked successfully: {} in controller", response); // Log the successful booking
        return response; // Return the response
    }
}