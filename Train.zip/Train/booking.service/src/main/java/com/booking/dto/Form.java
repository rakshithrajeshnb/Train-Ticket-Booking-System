package com.booking.dto;

import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Form {
    
    private String trainNo;
    private String trainName;
    private String type;
    private String prefenence;
    private String name;
    private String age;
    private String gender;
    private LocalDate departureDate;
}