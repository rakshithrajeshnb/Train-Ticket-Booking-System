package com.booking.dto;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TrainDetails {

    private String trainNo;
    private String trainName;
    private int av2a;
    private int av3a;
    private int avsl;
    private List<Dates> trainSchedule;
}