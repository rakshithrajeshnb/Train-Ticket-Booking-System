package com.booking.dto;

import java.util.Date;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Traindto {
    private String trainNo;
    private String trainName;
    private int avsl;
    private int av2a;
    private int av3a;
    private List<Dates> trainSchedule;
}