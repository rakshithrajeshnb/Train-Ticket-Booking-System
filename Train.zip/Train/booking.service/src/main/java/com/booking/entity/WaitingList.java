package com.booking.entity;

import java.time.LocalDate;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WaitingList {
    
    @Id
    @NotNull(message = "Serial number cannot be null")
    private String srNo;

    @NotNull(message = "Train number cannot be null")
    private String trainNo;

    @NotNull(message = "Train name cannot be null")
    private String trainName;

    @NotNull(message = "Type cannot be null")
    private String type;

    @NotNull(message = "Seat number cannot be null")
    private String seatNo;

    @NotNull(message = "Coach cannot be null")
    private String coach;

    @NotNull(message = "Status cannot be null")
    private String status;

    private String userId;

    @NotNull(message = "Departure date cannot be null")
    private LocalDate departureDate;

    @Size(min = 2, max = 50, message = "Name must be between 2 and 50 characters")
    private String name;

    @Pattern(regexp = "\\d+", message = "Age must be a number")
    private String age;

    @Pattern(regexp = "Male|Female|Other", message = "Gender must be Male, Female, or Other")
    private String gender;
}