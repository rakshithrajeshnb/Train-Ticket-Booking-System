package com.booking.logaspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspectAfter {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Before("within(com.booking.service.*)")
    public void logBeforeAllServiceClassMethods() {
        LOGGER.debug("For All Services");
    }

    @After("execution(* com.booking.service.TrainService.*(..))")
    public void logAfterAllMethods(JoinPoint joinPoint) {
        LOGGER.debug("****LoggingAspect.logAfterAllMethods() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* com.booking.service.TrainService.adddetails(..))")
    public void logAfterAddDetails(JoinPoint joinPoint) {
        LOGGER.debug("****LoggingAspect.logAfterAddDetails() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* com.booking.service.TrainService.removetrain(..))")
    public void logAfterRemoveTrain(JoinPoint joinPoint) {
        LOGGER.debug("****LoggingAspect.logAfterRemoveTrain() : " + joinPoint.getSignature().getName());
    }

    @After("execution(* com.booking.service.TrainService.bookTickets(..))")
    public void logAfterBookTickets(JoinPoint joinPoint) {
        LOGGER.debug("****LoggingAspect.logAfterBookTickets() : " + joinPoint.getSignature().getName());
    }
}