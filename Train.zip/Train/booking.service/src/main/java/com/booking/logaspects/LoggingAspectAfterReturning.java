package com.booking.logaspects;

import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspectAfterReturning {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @AfterReturning("execution(* com.booking.service.TrainService.*(..))")
    public void logAfterReturningAllMethods() throws Throwable {
        LOGGER.debug("****LoggingAspect.logAfterReturningAllMethods() ");
    }

    @AfterReturning(pointcut = "execution(* com.booking.service.TrainService.adddetails(..))", returning = "retVal")
    public void logAfterReturningAddDetails(Object retVal) throws Throwable {
        LOGGER.debug("****LoggingAspect.logAfterReturningAddDetails() ");
    }

    @AfterReturning(pointcut = "execution(* com.booking.service.TrainService.removetrain(..))", returning = "retVal")
    public void logAfterReturningRemoveTrain(Object retVal) throws Throwable {
        LOGGER.debug("****LoggingAspect.logAfterReturningRemoveTrain() ");
    }

    @AfterReturning(pointcut = "execution(* com.booking.service.TrainService.bookTickets(..))", returning = "retVal")
    public void logAfterReturningBookTickets(Object retVal) throws Throwable {
        LOGGER.debug("****LoggingAspect.logAfterReturningBookTickets() ");
    }
}