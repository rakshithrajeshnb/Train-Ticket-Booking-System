package com.booking.logaspects;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspectAround {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Around("execution(* com.booking.service.TrainService.*(..))")
    public void logAroundAllMethods(ProceedingJoinPoint joinPoint) throws Throwable {
        LOGGER.debug("****LoggingAspect.logAroundAddDetails() : " + joinPoint.getSignature().getName() + ": Before Method Execution");
        joinPoint.proceed();
        LOGGER.debug("****LoggingAspect.logAroundAddDetails() : " + joinPoint.getSignature().getName() + ": After Method Execution");
    }

    @Around("execution(* com.booking.service.TrainService.removetrain(..))")
    public void logAroundRemoveTrain(ProceedingJoinPoint joinPoint) throws Throwable {
        LOGGER.debug("****LoggingAspect.logAroundRemoveTrain() : " + joinPoint.getSignature().getName() + ": Before Method Execution");
        joinPoint.proceed();
        LOGGER.debug("****LoggingAspect.logAroundRemoveTrain() : " + joinPoint.getSignature().getName() + ": After Method Execution");
    }

    @Around("execution(* com.booking.service.TrainService.bookTickets(..))")
    public void logAroundBookTickets(ProceedingJoinPoint joinPoint) throws Throwable {
        LOGGER.debug("****LoggingAspect.logAroundBookTickets() : " + joinPoint.getSignature().getName() + ": Before Method Execution");
        joinPoint.proceed();
        LOGGER.debug("****LoggingAspect.logAroundBookTickets() : " + joinPoint.getSignature().getName() + ": After Method Execution");
    }
}