package com.booking.logaspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspectBefore {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Before("execution(* com.booking.service.TrainService.*(..))")
    public void logBeforeAllMethods(JoinPoint joinPoint) {
        LOGGER.info("****LoggingAspect.logBeforeAllMethods() : " + joinPoint.getSignature().getName());
    }

    @Before("execution(* com.booking.service.TrainService.adddetails(..))")
    public void logBeforeAddDetails(JoinPoint joinPoint) {
        LOGGER.info("****LoggingAspect.logBeforeAddDetails() : " + joinPoint.getSignature().getName());
    }

    @Before("execution(* com.booking.service.TrainService.removetrain(..))")
    public void logBeforeRemoveTrain(JoinPoint joinPoint) {
        LOGGER.info("****LoggingAspect.logBeforeRemoveTrain() : " + joinPoint.getSignature().getName());
    }

    @Before("execution(* com.booking.service.TrainService.bookTickets(..))")
    public void logBeforeBookTickets(JoinPoint joinPoint) {
        LOGGER.info("****LoggingAspect.logBeforeBookTickets() : " + joinPoint.getSignature().getName());
    }
}