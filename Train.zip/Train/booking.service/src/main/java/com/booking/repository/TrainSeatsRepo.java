package com.booking.repository;

import java.time.LocalDate;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.booking.entity.TrainSeats;

@Repository
public interface TrainSeatsRepo extends JpaRepository<TrainSeats, String> {



	void deleteByTrainNo(String id);

//	TrainSeats findFirstByStatusAndTypeAndCoachAndDepartureDate(String string, String type, String prefenence,
//			LocalDate departureDate);
//
//	TrainSeats findFirstByStatusAndTypeAndDepartureDate(String string, String type, LocalDate departureDate);

	TrainSeats findFirstByStatusAndTypeAndDepartureDateAndTrainNo(String string, String type, LocalDate departureDate,
			String trainNo);

	TrainSeats findFirstByStatusAndTypeAndCoachAndDepartureDateAndTrainNo(String string, String type, String prefenence,
			LocalDate departureDate, String trainNo);

}
