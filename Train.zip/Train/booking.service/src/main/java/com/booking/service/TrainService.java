package com.booking.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.booking.dto.Dates;
import com.booking.dto.Form;
import com.booking.dto.Traindto;
import com.booking.entity.TrainSeats;
import com.booking.entity.WaitingList;
import com.booking.exception.ResourceNotFoundException;
import com.booking.repository.TrainSeatsRepo;
import com.booking.repository.WaitingListRepo;
import com.booking.service.client.TrainSearchingClient;

@Service
public class TrainService {

	// Logger for logging important events and debugging information
	private static final Logger logger = LoggerFactory.getLogger(TrainService.class);

	@Autowired
	private TrainSeatsRepo repo;

	@Autowired
	private WaitingListRepo repo1;

	@Autowired
	private TrainSearchingClient client;

	// Lists to hold seat types
	List<String> sl = new ArrayList<>(
			List.of("Upper", "Middle", "Lower", "Upper", "Middle", "Lower", "SideUpper", "SideLower"));

	List<String> ac2t = new ArrayList<>(List.of("Upper", "Lower", "Upper", "Lower", "SideUpper", "SideLower"));

	int count = 0;
	int sr = 1;

	// Method to add train details
	public void adddetails(Traindto obj) {
		try {
			logger.info("Adding train details for train: {}", obj.getTrainNo());
			for (Dates date : obj.getTrainSchedule()) {
				for (int i = 1; i <= 15; i++) {
					count = 0;
					for (int j = 1; j <= 120; j++) {
						TrainSeats obj1 = new TrainSeats();
						obj1.setDepartureDate(date.getDepartureDate());
						obj1.setTrainNo(obj.getTrainNo());
						obj1.setTrainName(obj.getTrainName());
						if (i < 6) {
							obj1.setType("Sleeper");
							obj1.setSeatNo("SL/" + i + "/" + j);
							obj1.setCoach(sl.get(count));
							count = (count == 7) ? 0 : (count + 1);
						} else if (i > 5 && i < 11) {
							obj1.setType("2 Tier AC");
							obj1.setSeatNo("2A/" + i + "/" + j);
							obj1.setCoach(ac2t.get(count));
							count = (count == 5) ? 0 : (count + 1);
						} else {
							obj1.setType("3 Tier AC");
							obj1.setSeatNo("3A/" + i + "/" + j);
							obj1.setCoach(sl.get(count));
							count = (count == 7) ? 0 : (count + 1);
						}
						obj1.setStatus("NotBooked");
						obj1.setSrNo(String.valueOf(sr));
						repo.save(obj1);
						sr++;
					}
				}
			}
			logger.info("Train details added successfully for train: {}", obj.getTrainNo());
		} catch (Exception e) {
			logger.error("Error adding train details for train: {}", obj.getTrainNo(), e);
			throw new RuntimeException("Failed to add train details", e);
		}
	}

	// Method to remove train details
	public void removetrain(@RequestBody String id) {
		try {
			logger.info("Removing train with ID: {}", id);
			repo.deleteByTrainNo(id);
			logger.info("Train with ID {} removed successfully.", id);
		} catch (Exception e) {
			logger.error("Error removing train with ID: {}", id, e);
			throw new ResourceNotFoundException("Train with ID " + id + " not found");
		}
	}

	// Method to book tickets
	public List<Object> bookTickets(List<Form> lst) {
		logger.info("Booking tickets for forms: {}", lst);
		List<Object> ans = new ArrayList<>();
		try {
			for (Form form : lst) {
				logger.debug("Processing form: {}", form);
				if (form.getPrefenence().equalsIgnoreCase("No")) {
					TrainSeats seat3 = repo.findFirstByStatusAndTypeAndDepartureDateAndTrainNo("NotBooked",
							form.getType(), form.getDepartureDate(), form.getTrainNo());
					if (seat3 != null) {
						seat3.setName(form.getName());
						seat3.setAge(form.getAge());
						seat3.setGender(form.getGender());
						seat3.setStatus("Booked/Confirmed");
						seat3.setDepartureDate(form.getDepartureDate());
						repo.save(seat3);
						ans.add(seat3);
						List<String> lst1 = new ArrayList<>();
						lst1.add(form.getType());
						lst1.add(form.getTrainNo());
						client.lesscount(lst1);
						logger.info("Ticket booked successfully: {}", seat3);
					} else {
						throw new ResourceNotFoundException("No available seats found for the given criteria");
					}
				} else {
					TrainSeats seat = repo.findFirstByStatusAndTypeAndCoachAndDepartureDateAndTrainNo("NotBooked",
							form.getType(), form.getPrefenence(), form.getDepartureDate(), form.getTrainNo());
					if (seat != null) {
						seat.setName(form.getName());
						seat.setAge(form.getAge());
						seat.setGender(form.getGender());
						seat.setStatus("Booked/Confirmed");
						seat.setDepartureDate(form.getDepartureDate());
						repo.save(seat);
						ans.add(seat);
						List<String> lst1 = new ArrayList<>();
						lst1.add(form.getType());
						lst1.add(form.getTrainNo());
						client.lesscount(lst1);
						logger.info("Ticket booked successfully: {}", seat);
					} else {
						TrainSeats seat1 = repo.findFirstByStatusAndTypeAndDepartureDateAndTrainNo("NotBooked",
								form.getType(), form.getDepartureDate(), form.getTrainNo());
						if (seat1 != null) {
							seat1.setName(form.getName());
							seat1.setAge(form.getAge());
							seat1.setGender(form.getGender());
							seat1.setStatus("Booked/Confirmed");
							seat1.setDepartureDate(form.getDepartureDate());
							repo.save(seat1);
							ans.add(seat1);
							List<String> lst1 = new ArrayList<>();
							lst1.add(form.getType());
							lst1.add(form.getTrainNo());
							client.lesscount(lst1);
							logger.info("Ticket booked successfully: {} in service", seat1);
						} else {
							WaitingList seat2 = new WaitingList();
							seat2.setTrainNo(form.getTrainNo());
							seat2.setTrainName(form.getTrainName());
							seat2.setType(form.getType());
							long last = repo1.count() + 1;
							seat2.setSeatNo("WL/" + String.valueOf(last));
							seat2.setCoach(null);
							seat2.setStatus("Booked/Not Confirmed");
							seat2.setName(form.getName());
							seat2.setAge(form.getAge());
							seat2.setGender(form.getGender());
							seat2.setDepartureDate(form.getDepartureDate());
							ans.add(seat2);
							repo1.save(seat2);
							logger.info("Added to waiting list: {}", seat2);
						}
					}
				}
			}
		
		} catch (Exception e) {
			logger.error("Error booking tickets for forms: {}", lst, e);
			throw new RuntimeException("Failed to book tickets", e);
		}
		logger.info("Tickets booking process completed.");
		return ans;
	}
}