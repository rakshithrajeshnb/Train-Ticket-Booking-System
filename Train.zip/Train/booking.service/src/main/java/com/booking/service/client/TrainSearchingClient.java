package com.booking.service.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name="searching-service")
@Service
public interface TrainSearchingClient {
	
	@PutMapping("/lesscount")
	public void lesscount(@RequestBody List<String> lst);

}
