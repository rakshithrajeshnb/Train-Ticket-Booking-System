package com.booking.service;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.booking.dto.Dates;
import com.booking.dto.Form;
import com.booking.dto.Traindto;
import com.booking.entity.TrainSeats;
import com.booking.repository.TrainSeatsRepo;
import com.booking.repository.WaitingListRepo;
import com.booking.service.client.TrainSearchingClient;

@SpringBootTest
class TrainServiceTests {

    @Mock
    private TrainSeatsRepo trainSeatsRepo;

    @Mock
    private WaitingListRepo waitingListRepo;

    @Mock
    private TrainSearchingClient trainSearchingClient;

    @InjectMocks
    private TrainService trainService;

    @BeforeEach
    @Test
    void testAddDetails() {
        Traindto traindto = new Traindto();
        traindto.setTrainNo("12345");
        traindto.setTrainName("Test Train");
        traindto.setTrainSchedule(new ArrayList<>());

        Dates date = new Dates();
        date.setDepartureDate(LocalDate.now());
        traindto.getTrainSchedule().add(date);

        trainService.adddetails(traindto);

        verify(trainSeatsRepo, times(1800)).save(any(TrainSeats.class));
    }

    @Test
    void testRemoveTrain() {
        String trainNo = "12345";

        doNothing().when(trainSeatsRepo).deleteByTrainNo(trainNo);

        trainService.removetrain(trainNo);

        verify(trainSeatsRepo, times(1)).deleteByTrainNo(trainNo);
    }

    @Test
    void testBookTickets() {
        Form form = new Form();
        form.setTrainNo("12345");
        form.setTrainName("Test Train");
        form.setType("Sleeper");
        form.setPrefenence("No");
        form.setDepartureDate(LocalDate.now());
        form.setName("John Doe");
        form.setAge("30");
        form.setGender("Male");

        List<Form> forms = new ArrayList<>();
        forms.add(form);

        TrainSeats seat = new TrainSeats();
        seat.setTrainNo("12345");
        seat.setStatus("NotBooked");

        when(trainSeatsRepo.findFirstByStatusAndTypeAndDepartureDateAndTrainNo(eq("NotBooked"), eq("Sleeper"), eq(form.getDepartureDate()), eq("12345"))).thenReturn(seat);
        doNothing().when(trainSearchingClient).lesscount(anyList());

        List<Object> result = trainService.bookTickets(forms);

        assertEquals(1, result.size());
        verify(trainSeatsRepo, times(1)).save(any(TrainSeats.class));
        verify(trainSearchingClient, times(1)).lesscount(anyList());
    }
}